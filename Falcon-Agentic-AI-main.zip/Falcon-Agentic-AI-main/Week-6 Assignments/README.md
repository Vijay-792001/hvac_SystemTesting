# Week 6 - Hands-on Practice

These notebooks are learner-facing practice scaffolds for Week 6. Each notebook is intentionally incomplete and contains `TODO` sections that users must finish by writing the missing code.

The Week 6 hands-ons focus on two themes:

- evaluating RAG answer quality
- adding guardrails for safer RAG behavior

## Practice sequence

| Notebook | Theme | What learners implement | Matching solution |
| --- | --- | --- | --- |
| HandsOn1.ipynb | Evaluation | Evaluate one RAG answer using context relevance, faithfulness, answer relevance, and completeness | Week6/Hands-on-Practice-Solution/HandsOn1.ipynb |
| HandsOn2.ipynb | Evaluation | Compare retriever `k` values and measure how retrieval changes answer quality | Week6/Hands-on-Practice-Solution/HandsOn2.ipynb |
| HandsOn3.ipynb | Evaluation | Run batch evaluation across a small benchmark and summarize average scores | Week6/Hands-on-Practice-Solution/HandsOn3.ipynb |
| HandsOn4.ipynb | Guardrails | Implement LangChain middleware for input blocking, PII redaction, and sanitized-input capture | Week6/Hands-on-Practice-Solution/HandsOn4.ipynb |
| HandsOn5.ipynb | Guardrails | Implement LangChain `after_agent` middleware for groundedness review and review escalation | Week6/Hands-on-Practice-Solution/HandsOn5.ipynb |

## Notebook purpose

- `HandsOn1.ipynb` introduces single-response RAG evaluation.
- `HandsOn2.ipynb` shows how retrieval configuration can change answer quality.
- `HandsOn3.ipynb` turns evaluation into a small benchmark workflow.
- `HandsOn4.ipynb` introduces LangChain middleware for input guardrails.
- `HandsOn5.ipynb` introduces LangChain middleware for output review and safer response handling.

## Learner workflow

1. Create `Week6/.env` and set `OPENAI_API_KEY`. You may also set `OPENAI_MODEL`.
2. Open the notebook with its working directory set to `Week6/Hands-on-Practice`.
3. Run the setup cells first.
4. Complete every `TODO` section before running the final cells.
5. Read the printed guidance in each notebook to understand what should happen at each step.
6. Run the notebook end to end and inspect the output carefully.
7. Compare your implementation with the matching notebook in `Week6/Hands-on-Practice-Solution`.

## Concepts covered

- context relevance
- faithfulness
- answer relevance
- completeness
- keyword-based retrieval scoring
- LLM-as-a-judge evaluation
- batch evaluation
- prompt injection detection
- PII redaction with LangChain middleware
- groundedness review with LangChain middleware
- review escalation

## Safety

All notebooks use mock classroom-safe policy content. They demonstrate evaluation and guardrail logic only, and they do not trigger real enterprise actions, account changes, or external system updates.
