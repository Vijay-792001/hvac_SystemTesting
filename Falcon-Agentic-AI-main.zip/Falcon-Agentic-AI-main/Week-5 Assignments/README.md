# Week 3 Practice Use Cases Based on Week 1 and Week 2

These five intermediate assessment-style activities use only the capabilities introduced in the Week 1 and Week 2 instructor-led demonstrations.

| File | Enterprise domain | Main concepts |
| --- | --- | --- |
| `01_supplier_invoice_exception_control.md` | Accounts payable | LangGraph state, parallel checks, routing, deterministic matching |
| `02_privileged_access_governance.md` | Identity governance | CrewAI roles/tasks, explicit context, least-privilege tools |
| `03_manufacturing_quality_deviation_triage.md` | Manufacturing quality | Typed state, numeric tools, conditional routing, edge cases |
| `04_enterprise_contract_obligation_review.md` | Vendor management | CrewAI Flow, parallel tools, date logic, reviewer agent |
| `05_service_outage_response_coordinator.md` | IT operations | Direct-LLM comparison, agent planning, tools, routing, retries |

## Common expectations

- Learners may use any LLM provider and must identify the provider/model.
- Credentials must be loaded from environment variables, never embedded in a notebook.
- Exact rules, arithmetic, dates, membership checks, and routes belong in Python tools.
- LLMs may plan, summarize, and explain only supplied evidence.
- Every recommendation requires human review; no use case performs a real-world action.
- Runs must expose intermediate state/task outputs and use bounded generation, retry, and iteration settings.
- RAG, embeddings, vector databases, and persistent memory are outside this assessment scope.

Each file is intentionally a different business problem and tests a different workflow shape. The mock records contain normal, exception, missing-data, boundary, and escalation cases.
