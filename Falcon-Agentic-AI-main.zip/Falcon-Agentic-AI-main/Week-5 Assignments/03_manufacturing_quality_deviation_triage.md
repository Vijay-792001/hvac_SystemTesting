# Use Case 3: Manufacturing Quality Deviation Triage

## Difficulty and purpose

**Level:** Intermediate  
**Suggested framework:** LangGraph  
**Assessment focus:** conditional routing, shared state, deterministic severity scoring, error handling, and explainable synthesis

## Scenario

A manufacturer records quality deviations from production lines. Engineers need a consistent triage packet before deciding whether to contain a batch or start a formal investigation. Build a workflow that classifies supplied measurements and recommends the next human review. It must not stop machinery, quarantine inventory, release product, or create a regulatory report.

## Mock data

```python
deviations = [
 {"deviation_id":"QD-501","batch_id":"B-880","product":"Valve-A","metric":"diameter_mm","observed":10.08,"lower":9.90,"upper":10.10,"sample_failures":1,"sample_size":50,"customer_impact":False,"repeat_count_30d":0},
 {"deviation_id":"QD-502","batch_id":"B-881","product":"Valve-A","metric":"diameter_mm","observed":10.24,"lower":9.90,"upper":10.10,"sample_failures":7,"sample_size":50,"customer_impact":False,"repeat_count_30d":2},
 {"deviation_id":"QD-503","batch_id":"B-882","product":"Seal-C","metric":"leak_rate","observed":3.8,"lower":0.0,"upper":2.0,"sample_failures":4,"sample_size":20,"customer_impact":True,"repeat_count_30d":1},
 {"deviation_id":"QD-504","batch_id":"B-883","product":"Housing-B","metric":"surface_defect","observed":6,"lower":0,"upper":3,"sample_failures":2,"sample_size":0,"customer_impact":False,"repeat_count_30d":0},
 {"deviation_id":"QD-505","batch_id":"B-884","product":"Seal-C","metric":"leak_rate","observed":2.1,"lower":0.0,"upper":2.0,"sample_failures":1,"sample_size":20,"customer_impact":False,"repeat_count_30d":3}
]
```

## Deterministic scoring specification

Calculate in Python:

- `out_of_spec`: observed outside inclusive lower/upper bounds;
- `failure_rate`: `sample_failures / sample_size` (invalid when sample size is zero);
- add 2 points for out-of-spec;
- add 2 points when failure rate is at least 10%;
- add 3 points for known customer impact;
- add 1 point when `repeat_count_30d >= 2`.

Routes: invalid/missing inputs -> `DATA_VALIDATION`; score 0-1 -> `MONITOR`; score 2-4 -> `ENGINEERING_REVIEW`; score 5+ -> `URGENT_QUALITY_REVIEW`.

## Required graph

```text
START -> Normalize Record -> Calculate Evidence -> Severity Router
      -> [Validation Packet | Monitor Packet | Engineering Packet | Urgent Packet] -> END
```

The normalization node may use an LLM only to produce a factual description; Python must validate types and required fields first. The evidence node performs all arithmetic. Packet nodes use reusable prompts but must preserve the computed route, score, and measurements.

## Shared state

```python
deviation
validation_errors
normalized_summary
evidence
severity_score
route
final_packet
steps_completed
```

## Expected final structure

```python
{
 "deviation_id":"QD-502",
 "route":"ENGINEERING_REVIEW",
 "severity_score":5,
 "evidence":{"out_of_spec":True,"failure_rate":0.14,"customer_impact":False,"repeat_count_30d":2},
 "recommended_human_action":"Quality engineer reviews evidence and determines containment.",
 "action_performed":False
}
```

The example route above must be corrected by the learner if it conflicts with the scoring thresholds. Document the detected inconsistency and use the deterministic result. This is an intentional requirements-validation check.

## Submission requirements

- One executable notebook processing all five deviations with isolated state.
- Typed state, graph visualization, named model/retry/token/temperature controls, and maximum 600 generated tokens.
- Unit checks for exact-bound values, zero sample size, negative counts, and missing bounds.
- Print evidence before the final packet and explain every score component.
- Compare deterministic measurement handling with LLM narrative generation.

## Restrictions and assessment checks

- Never invent a root cause from the measurements.
- Never claim a batch was contained, released, or reported.
- Do not let prompts calculate rates, scores, or routes.
- Assess correct edge-case handling, conditional edges, state updates, evidence fidelity, and human escalation language.

