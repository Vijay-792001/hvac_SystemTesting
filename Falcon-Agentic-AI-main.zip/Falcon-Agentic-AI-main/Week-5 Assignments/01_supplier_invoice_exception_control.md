# Use Case 1: Supplier Invoice Exception Control Tower

## Difficulty and purpose

**Level:** Intermediate  
**Suggested framework:** LangGraph  
**Assessment focus:** typed state, deterministic tools, conditional routing, parallel analysis, prompt templates, and human approval

## Scenario

An enterprise accounts-payable team receives invoices that must be compared with purchase orders (POs) and goods-receipt records. Build an agentic workflow that validates each invoice, identifies exceptions, and prepares a reviewer brief. The system must not approve, reject, post, or pay an invoice.

## Mock data

```python
invoices = [
    {"invoice_id":"INV-701","supplier_id":"SUP-10","po_id":"PO-9001","amount_inr":118000,"currency":"INR","invoice_date":"2026-08-05","bank_account":"XXXX2210"},
    {"invoice_id":"INV-702","supplier_id":"SUP-11","po_id":"PO-9002","amount_inr":264000,"currency":"INR","invoice_date":"2026-08-06","bank_account":"XXXX7712"},
    {"invoice_id":"INV-703","supplier_id":"SUP-12","po_id":"PO-9003","amount_inr":79000,"currency":"INR","invoice_date":"2026-08-07","bank_account":"XXXX9918"},
    {"invoice_id":"INV-704","supplier_id":"SUP-13","po_id":"PO-9999","amount_inr":43000,"currency":"INR","invoice_date":"2026-08-08","bank_account":"XXXX3100"},
    {"invoice_id":"INV-705","supplier_id":"SUP-14","po_id":"PO-9005","amount_inr":155000,"currency":"USD","invoice_date":"2026-08-09","bank_account":""}
]

purchase_orders = {
    "PO-9001":{"supplier_id":"SUP-10","po_amount_inr":120000,"approved":True},
    "PO-9002":{"supplier_id":"SUP-11","po_amount_inr":240000,"approved":True},
    "PO-9003":{"supplier_id":"SUP-12","po_amount_inr":80000,"approved":True},
    "PO-9005":{"supplier_id":"SUP-14","po_amount_inr":155000,"approved":True}
}

goods_receipts = {
    "PO-9001":{"received_percent":100,"quality_hold":False},
    "PO-9002":{"received_percent":100,"quality_hold":False},
    "PO-9003":{"received_percent":75,"quality_hold":False},
    "PO-9005":{"received_percent":100,"quality_hold":True}
}

policy = {
    "allowed_currency":"INR",
    "amount_tolerance_percent":2,
    "minimum_received_percent":100,
    "finance_approval_above_inr":200000
}
```

## Required workflow

```text
START -> Invoice Intake -> [Three-Way Match || Supplier Risk Check]
      -> Exception Router -> [Ready Brief | Exception Brief | Missing-Data Brief] -> END
```

1. **Invoice Intake node:** validate required fields and create a factual summary.
2. **Three-Way Match tool:** use Python to compare supplier, invoice amount, PO amount, approval, receipt percentage, and quality hold.
3. **Supplier Risk Check tool:** assign `LOW`, `MEDIUM`, or `HIGH` from supplied facts only. A missing PO is `HIGH`; a quality hold or partial receipt is `MEDIUM`; otherwise `LOW`.
4. Run the match and risk checks as parallel branches after intake.
5. **Exception Router:** select exactly one route using deterministic Python.
6. **Brief Composer:** use an LLM to explain the verified result without changing it.

## Decision rules

Apply in this order:

1. Missing required data -> `MISSING_DATA`.
2. Missing/unapproved PO, supplier mismatch, unsupported currency, amount outside tolerance, incomplete receipt, or quality hold -> `EXCEPTION_REVIEW`.
3. Otherwise -> `READY_FOR_AP_REVIEW`.

Add `Finance Manager` to required approvers when the invoice amount exceeds the configured threshold. Arithmetic and status selection must be Python-based.

## Required shared state

```python
invoice
intake_result
match_result
risk_result
route
final_brief
steps_completed
errors
```

Use a separate execution/thread ID for every invoice.

## Expected final structure

```python
{
  "invoice_id": "INV-701",
  "status": "READY_FOR_AP_REVIEW",
  "match_checks": {},
  "risk_level": "LOW",
  "required_approvers": ["AP Reviewer"],
  "recommended_human_action": "Review the verified match evidence.",
  "action_performed": False
}
```

## Technical and submission requirements

- Use reusable prompt templates and a typed state.
- Declare model, low temperature, maximum 600 output tokens, maximum two model retries, and bounded agent iterations.
- Handle unknown PO IDs and invalid numeric values without crashing.
- Display parallel branch outputs, route, and final state for all five invoices.
- Submit one executable notebook plus a short workflow diagram and a paragraph separating deterministic work from LLM work.
- Do not use real finance systems, RAG, or persistent memory.

## Assessment checks

- Exact match calculations are not delegated to the LLM.
- Parallel branches write to different state fields.
- Routing is reproducible and every record reaches one terminal branch.
- The final brief preserves the computed status and includes a human gate.

