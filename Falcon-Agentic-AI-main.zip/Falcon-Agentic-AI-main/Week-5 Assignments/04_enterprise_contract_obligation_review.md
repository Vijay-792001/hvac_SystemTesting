# Use Case 4: Enterprise Contract Obligation Review Desk

## Difficulty and purpose

**Level:** Intermediate  
**Suggested framework:** CrewAI Flow  
**Assessment focus:** parallel branches, conditional flow, deterministic date/value tools, reviewer agent, and bounded execution

## Scenario

A vendor-management office maintains structured extracts of active contracts. Build a workflow that reviews renewal timing, spend variance, insurance evidence, and data-processing obligations, then prepares a contract-owner brief. This is operational triage, not legal advice. The system must not renew, terminate, amend, sign, or notify a vendor.

## Mock data

Assume the review date is `2026-08-27`.

```python
contracts = [
 {"contract_id":"CT-801","vendor":"Nimbus Hosting","owner":"Cloud Ops","end_date":"2026-10-15","notice_days":30,"annual_value_inr":4800000,"approved_value_inr":5000000,"insurance_expiry":"2027-01-31","personal_data":True,"dpa_present":True},
 {"contract_id":"CT-802","vendor":"Northstar Facilities","owner":"Workplace","end_date":"2026-09-20","notice_days":60,"annual_value_inr":2200000,"approved_value_inr":2000000,"insurance_expiry":"2026-07-31","personal_data":False,"dpa_present":False},
 {"contract_id":"CT-803","vendor":"Insight Metrics","owner":"Marketing","end_date":"2027-02-28","notice_days":45,"annual_value_inr":1250000,"approved_value_inr":1250000,"insurance_expiry":"2027-05-01","personal_data":True,"dpa_present":False},
 {"contract_id":"CT-804","vendor":"Rapid Logistics","owner":"Supply Chain","end_date":"2026-08-20","notice_days":30,"annual_value_inr":3100000,"approved_value_inr":3200000,"insurance_expiry":"2026-12-31","personal_data":False,"dpa_present":False},
 {"contract_id":"CT-805","vendor":"SecureShred","owner":"Compliance","end_date":"","notice_days":90,"annual_value_inr":900000,"approved_value_inr":900000,"insurance_expiry":"2026-11-30","personal_data":True,"dpa_present":True}
]
```

## Required Flow

```text
START -> [Obligation Planner || Evidence Tool Branch]
Evidence Tool Branch -> [Date/Notice Check || Commercial Check || Compliance Check]
All branches -> Risk Router -> [Incomplete | Standard | Elevated] -> Reviewer Agent -> END
```

Implement independent checks concurrently where the framework permits. The planner produces a review plan only. Python tools parse ISO dates, calculate days remaining and variance percentage, and evaluate Boolean rules.

## Deterministic rules

- Missing required field or invalid date -> `INCOMPLETE_RECORD`.
- Notice deadline = end date minus notice days.
- A passed notice deadline, expired contract, expired insurance, positive value variance above 5%, or personal data without a DPA is a risk flag.
- Two or more flags, or an already expired contract, -> `ELEVATED_REVIEW`.
- One flag -> `OWNER_REVIEW`.
- No flags -> `STANDARD_MONITORING`.

Required reviewers derive from flags: Contract Owner always; Procurement for value variance; Risk for insurance; Privacy for missing DPA; Legal for missed notice or expired contract.

## Flow state and final output

State must hold the source record, plan, results from all three tool branches, route, reviewer list, final brief, errors, and completed steps.

```python
{
 "contract_id":"CT-803",
 "status":"OWNER_REVIEW",
 "days_to_end":185,
 "risk_flags":["PERSONAL_DATA_WITHOUT_DPA"],
 "required_reviewers":["Contract Owner","Privacy"],
 "recommended_next_step":"The named humans review the supplied evidence.",
 "legal_advice_provided":False,
 "action_performed":False
}
```

## Submission requirements

- One executable notebook covering every contract.
- Reusable prompts, typed Flow state, route visibility, and branch-level outputs.
- Named limits: 600 output tokens, two retries, and three agent iterations; use low temperature.
- Tool tests for leap dates, invalid dates, division by zero, exactly 5% variance, and notice deadline equal to review date.
- A short analysis of concurrency benefits and which fields must not be concurrently overwritten.

## Restrictions and assessment checks

- Treat the structured extract as the complete mock source; do not add RAG or legal knowledge.
- The LLM cannot interpret legal enforceability or invent clauses.
- No external email, contract-management, signature, or vendor action.
- Assess correct fan-out/join behavior, deterministic dates, rule priority, reviewer derivation, and safe final language.

