# Use Case 2: Privileged Access Governance Orchestrator

## Difficulty and purpose

**Level:** Intermediate  
**Suggested framework:** CrewAI with sequential tasks  
**Assessment focus:** role-based collaboration, least-privilege tool assignment, explicit task context, deterministic policy evaluation, and safe recommendations

## Scenario

An identity-governance team reviews temporary privileged-access requests. Build a crew that registers a request, checks entitlement policy, assesses segregation-of-duties (SoD) conflicts, and prepares an approval packet. It must never create an account, grant a role, contact an approver, or claim that access was provisioned.

## Mock data

```python
access_requests = [
 {"request_id":"AR-301","employee_id":"E-101","department":"Finance","role":"ERP_FIN_REPORT","environment":"PROD","duration_days":14,"manager":"M-11","business_reason":"Quarter-close reporting"},
 {"request_id":"AR-302","employee_id":"E-102","department":"Finance","role":"ERP_VENDOR_ADMIN","environment":"PROD","duration_days":30,"manager":"M-12","business_reason":"Supplier master cleanup"},
 {"request_id":"AR-303","employee_id":"E-103","department":"Engineering","role":"CLOUD_PROD_ADMIN","environment":"PROD","duration_days":5,"manager":"M-13","business_reason":"Production migration support"},
 {"request_id":"AR-304","employee_id":"E-104","department":"HR","role":"HR_PAYROLL_ADMIN","environment":"TEST","duration_days":120,"manager":"M-14","business_reason":"Payroll testing"},
 {"request_id":"AR-305","employee_id":"E-105","department":"Operations","role":"ERP_PO_APPROVER","environment":"PROD","duration_days":10,"manager":"","business_reason":"Back-up coverage"}
]

current_roles = {
 "E-101":["ERP_GL_VIEW"], "E-102":["ERP_PAYMENT_APPROVER"],
 "E-103":["CLOUD_DEV_ADMIN"], "E-104":["HR_EMPLOYEE_VIEW"], "E-105":["ERP_PO_CREATOR"]
}

role_policy = {
 "ERP_FIN_REPORT":{"departments":["Finance"],"max_days":30,"security_approval":False},
 "ERP_VENDOR_ADMIN":{"departments":["Finance"],"max_days":14,"security_approval":True},
 "CLOUD_PROD_ADMIN":{"departments":["Engineering","Operations"],"max_days":7,"security_approval":True},
 "HR_PAYROLL_ADMIN":{"departments":["HR"],"max_days":90,"security_approval":True},
 "ERP_PO_APPROVER":{"departments":["Operations","Finance"],"max_days":30,"security_approval":False}
}

sod_conflicts = [
 ["ERP_VENDOR_ADMIN","ERP_PAYMENT_APPROVER"],
 ["ERP_PO_APPROVER","ERP_PO_CREATOR"]
]
```

## Required crew and task flow

```text
Request Registrar -> Entitlement Policy Analyst -> SoD Control Analyst -> Governance Packet Reviewer
```

- **Request Registrar:** factual intake and missing-field detection; no tools.
- **Entitlement Policy Analyst:** receives intake context and alone receives `check_role_policy`.
- **SoD Control Analyst:** receives prior results and alone receives `check_sod_conflicts`.
- **Governance Packet Reviewer:** composes a concise packet from verified task outputs; no provisioning tools.

Use `Process.sequential` and pass outputs through explicit task context. Tools must be deterministic Python functions returning structured objects.

## Decision rules

1. Missing required field -> `MORE_INFORMATION_REQUIRED`.
2. Unknown role, disallowed department, excessive duration, or any SoD conflict -> `CONTROL_REVIEW_REQUIRED`.
3. Otherwise -> `READY_FOR_HUMAN_APPROVAL`.

All valid requests require the manager and application owner. Add security approval when configured for the role or whenever the environment is `PROD` and the role contains `ADMIN`.

## Expected output

```python
{
 "request_id":"AR-301",
 "status":"READY_FOR_HUMAN_APPROVAL",
 "entitlement_checks":{},
 "sod_conflicts":[],
 "required_approvers":["Manager","Application Owner"],
 "expiry_required":True,
 "action_performed":False
}
```

## Reliability and prompt requirements

- State the provider/model and load secrets from environment variables.
- Use named limits: at most 600 output tokens, two retries, and three iterations per agent.
- Use low randomness suitable for governance decisions.
- Prompts must define role, supplied context, structured output, fact boundaries, and prohibited actions.
- Configure tool access so only the relevant specialist has each tool.

## Submission requirements

Submit one executable notebook that runs all five requests independently and displays every task output. Include tool unit checks for: unknown role, reversed SoD-pair ordering, empty manager, and duration boundary. Explain why policy/SoD decisions are deterministic while the LLM only summarizes evidence.

## Restrictions and assessment checks

- No real directory, IAM, email, ticketing, or approval integration.
- No LLM-based equality, membership, duration, or SoD checks.
- The final agent cannot override the deterministic status.
- Award credit for explicit task context, least-privilege tools, bounded execution, traceable evidence, and human approval.

