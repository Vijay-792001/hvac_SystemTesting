# Use Case 5: Enterprise Service Outage Response Coordinator

## Difficulty and purpose

**Level:** Intermediate  
**Suggested frameworks:** implement a direct-LLM baseline, then LangGraph or CrewAI  
**Assessment focus:** comparing an LLM response with an agent workflow, planning, tool execution, conditional routing, state, and human approval

## Scenario

An enterprise operations center receives monitoring events for business services. Build a coordinator that correlates supplied signals, calculates incident priority, selects a runbook, and drafts a response plan. The workflow must not restart a service, alter infrastructure, page staff, update a status page, or close an incident.

## Mock data

```python
events = [
 {"event_id":"EV-901","service":"Checkout API","environment":"PROD","availability_pct":91.2,"latency_ms":2400,"error_rate_pct":18.0,"affected_users":4200,"minutes_active":12,"dependency":"Payment Gateway","change_in_last_2h":True},
 {"event_id":"EV-902","service":"HR Portal","environment":"PROD","availability_pct":99.2,"latency_ms":850,"error_rate_pct":2.5,"affected_users":180,"minutes_active":35,"dependency":"Identity Service","change_in_last_2h":False},
 {"event_id":"EV-903","service":"Analytics Batch","environment":"TEST","availability_pct":87.0,"latency_ms":0,"error_rate_pct":28.0,"affected_users":12,"minutes_active":55,"dependency":"Data Warehouse","change_in_last_2h":True},
 {"event_id":"EV-904","service":"Customer CRM","environment":"PROD","availability_pct":96.5,"latency_ms":1350,"error_rate_pct":8.0,"affected_users":900,"minutes_active":8,"dependency":"Identity Service","change_in_last_2h":False},
 {"event_id":"EV-905","service":"Payroll API","environment":"PROD","availability_pct":None,"latency_ms":3100,"error_rate_pct":15.0,"affected_users":700,"minutes_active":20,"dependency":"Database Cluster","change_in_last_2h":True}
]

runbooks = {
 "Payment Gateway":["validate dependency health","compare recent changes","prepare rollback decision for human approval"],
 "Identity Service":["validate authentication health","check token errors","prepare failover decision for human approval"],
 "Data Warehouse":["validate job queue","inspect dependency status","prepare rerun decision for human approval"],
 "Database Cluster":["validate connection health","inspect saturation metrics","prepare failover decision for human approval"]
}
```

## Part A: Baseline

Create one reusable prompt and one LLM request that produces a response-plan draft for an event. Record its limitations: no deterministic priority guarantee, no explicit state transitions, and no executable tool boundary. Do not ask the baseline to perform actions.

## Part B: Agent workflow

```text
START -> Validate Event -> Response Planner
      -> [Priority Calculator || Runbook Retriever]
      -> Priority Router -> [P1 | P2 | P3 | Data Issue] Brief -> END
```

- The planner decomposes the goal into ordered, verifiable checks.
- The priority calculator and runbook retriever are deterministic tools and execute independently.
- The router uses Python and never an LLM.
- The final LLM explains the verified result and includes decision owners.

## Priority rules

First route missing critical metrics to `DATA_QUALITY_REVIEW`. Otherwise:

- `P1`: production and (`availability < 95` or `error rate >= 15`) and `affected_users >= 1000`;
- `P2`: production and (`availability < 99.5` or `error rate >= 5`) and `affected_users >= 100`;
- `P3`: all other valid events.

Add `Change Manager` when a recent change exists, `Service Owner` for every event, and `Incident Commander` for P1. Preserve priority ordering exactly.

## Shared state and output

```python
event
validation_errors
response_plan
priority_result
runbook_result
route
final_brief
steps_completed
```

```python
{
 "event_id":"EV-901",
 "priority":"P1",
 "evidence":{},
 "runbook_steps":[],
 "decision_owners":["Service Owner","Change Manager","Incident Commander"],
 "recommended_human_action":"Validate evidence and authorize any operational action.",
 "action_performed":False
}
```

## Reliability and failure handling

- Declare provider/model, low temperature, maximum 600 output tokens, two retries, and bounded iterations.
- Add bounded mock-tool retries and timeouts; simulate one transient retrieval failure and show safe recovery.
- Unknown dependencies return a structured `RUNBOOK_NOT_FOUND` result, not invented guidance.
- Each event uses isolated state/checkpoint identifiers.

## Submission requirements

Submit one executable notebook containing both parts, all five runs, intermediate outputs, and a comparison table covering reliability, traceability, tool boundaries, routing, and complexity. Include tests at exact priority thresholds and for missing values.

## Restrictions and assessment checks

- No real monitoring, paging, infrastructure, ticketing, or status-page APIs.
- The LLM must not calculate priority or invent a missing runbook.
- Assess accurate deterministic routing, independent branch execution, safe tool failures, prompt quality, state traceability, and a thoughtful baseline-versus-agent comparison.

