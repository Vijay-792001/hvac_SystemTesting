# Week 4 — Hands-on Practice

These notebooks mirror `../Hands-on-Practice-Solution`. Agent logic, tools, workflows, and persistence helpers are complete. Learners implement only the FastAPI and Pydantic TODOs.

## Practice inventory

| Notebook | Completed foundation | Learner FastAPI work |
| --- | --- | --- |
| [HandsOn1.ipynb](HandsOn1.ipynb) | Single agent and OpenAI-backed tool | Schemas, health route, and architecture-selection POST route |
| [HandsOn2.ipynb](HandsOn2.ipynb) | Three sequential LangGraph agents, tools, SQLite repository | CRUD schemas and routes under `/sequential-workflows` |
| [HandsOn3.ipynb](HandsOn3.ipynb) | Three parallel CrewAI specialists, tools, SQLite repository | CRUD schemas and routes under `/parallel-cases` |

## Learning outcomes

Learners will:

- explain FastAPI's role in agent serving;
- define Pydantic request and response models;
- distinguish bodies, path parameters, and query parameters;
- expose an agent through a typed POST route;
- implement `GET`, `POST`, `PUT`, and `DELETE` operations;
- use correct `200`, `201`, `204`, `404`, `422`, and `500` behavior;
- keep blocking calls off the async event loop;
- test with Swagger UI and ReDoc;
- distinguish workflow state from persistent SQLite memory;
- preserve authentication and human-approval boundaries.

## Provided versus TODO

Provided:

- OpenAI-only setup;
- mock data and safe tools;
- single-agent, sequential LangGraph, and parallel CrewAI implementations;
- typed workflow state, visualization, and SQLite repository helpers;
- FastAPI explanations and route requirements.

TODO markers appear only in FastAPI-related cells:

- Pydantic API schemas;
- FastAPI applications and routes;
- request/response construction;
- CRUD endpoint implementations;
- query/path parameters, exceptions, and status codes;
- route inspection after implementation.

Do not change completed agent, tool, workflow, or persistence behavior unless extending the exercise.

## Setup

Create `Week4/.env`:

```env
OPENAI_API_KEY=your-real-key
OPENAI_MODEL=gpt-5.1
```

Never hard-code or commit a real key. Run cells in order.

## Completion sequence

1. Run the completed agent/workflow directly.
2. Implement Pydantic models.
3. Implement `GET /health` and required serving/CRUD routes.
4. Add response models, tags, parameters, and status codes.
5. Offload blocking calls with `run_in_threadpool` where directed.
6. Start Uvicorn and test `/docs`, `/redoc`, valid input, `422`, `404`, and `204`.
7. Compare with the solution after completing the exercise.

## Default ports

| Notebook | Port |
| --- | ---: |
| HandsOn1 | 8000 |
| HandsOn2 | 8001 |
| HandsOn3 | 8002 |

Server cells run until interrupted. Runtime databases must contain mock data only.

