# Guided Practice: Customer Return Resolution API

> **Required submission file:** `Interium_assessment_2.ipynb`

Submit the complete solution as one executable Jupyter Notebook (`.ipynb`) using the exact filename shown above.

## Expected submission

Submit `Interium_assessment_2.ipynb` as one clean, executable Jupyter Notebook containing:

1. setup and secure OpenAI configuration;
2. mock data and deterministic policy tool;
3. reusable prompts and explicit LLM tool contract;
4. typed state and role-based agents/nodes;
5. framework topology showing sequential, parallel, join, and conditional routing;
6. SQLite schema and memory retrieval;
7. Pydantic schemas;
8. the required FastAPI create/read routes;
9. all five direct workflow tests;
10. API validation evidence from Swagger or a test client;
11. a short explanation of state versus persistent memory;
12. safety and human-approval notes;
13. a brief comparison with a direct LLM call, a single-agent solution, and the alternative framework.

## Scenario

An e-commerce support team receives customer return requests. Each request must be registered, checked against deterministic return rules, and converted into a safe recommendation for a human support agent.

Build an agent workflow and expose it through FastAPI. Choose **LangGraph or CrewAI**. Persist completed cases in SQLite and provide create/read API routes. It may recommend a resolution, but it must not issue a refund, create a shipping label, change an order, or approve an exception.

This is an intermediate guided activity. Use OpenAI only for interpretation and communication; exact policy decisions belong in Python tools.

## Mock input

Use these five requests:

```python
return_requests = [
    {
        "case_id": "RET-1001",
        "customer_id": "C-201",
        "order_id": "O-5001",
        "item_category": "Electronics",
        "days_since_delivery": 8,
        "item_opened": False,
        "reason": "The keyboard layout is not suitable.",
        "purchase_amount_inr": 4200
    },
    {
        "case_id": "RET-1002",
        "customer_id": "C-202",
        "order_id": "O-5002",
        "item_category": "Electronics",
        "days_since_delivery": 18,
        "item_opened": True,
        "reason": "The headset intermittently disconnects.",
        "purchase_amount_inr": 6800
    },
    {
        "case_id": "RET-1003",
        "customer_id": "C-203",
        "order_id": "O-5003",
        "item_category": "Personal Care",
        "days_since_delivery": 3,
        "item_opened": True,
        "reason": "Changed my mind.",
        "purchase_amount_inr": 900
    },
    {
        "case_id": "RET-1004",
        "customer_id": "C-204",
        "order_id": "O-5004",
        "item_category": "Home",
        "days_since_delivery": 5,
        "item_opened": False,
        "reason": "",
        "purchase_amount_inr": 12500
    },
    {
        "case_id": "RET-1005",
        "customer_id": "C-205",
        "order_id": "O-5005",
        "item_category": "Home",
        "days_since_delivery": 31,
        "item_opened": False,
        "reason": "The size does not fit the available space.",
        "purchase_amount_inr": 22000
    }
]
```

Use this policy:

```python
return_policy = {
    "standard_window_days": 15,
    "non_returnable_if_opened": ["Personal Care"],
    "manual_review_amount_inr": 10000,
    "reason_required": True
}
```

## Sample input and output

Sample request body for `POST /return-cases`:

```json
{
  "case_id": "RET-1001",
  "customer_id": "C-201",
  "order_id": "O-5001",
  "item_category": "Electronics",
  "days_since_delivery": 8,
  "item_opened": false,
  "reason": "The keyboard layout is not suitable.",
  "purchase_amount_inr": 4200
}
```

Sample `201 Created` response:

```json
{
  "id": 1,
  "case_id": "RET-1001",
  "status": "ELIGIBLE_FOR_HUMAN_REVIEW",
  "policy_result": {
    "within_window": true,
    "category_rule_passed": true,
    "reason_present": true,
    "manual_review_required": false,
    "status": "ELIGIBLE_FOR_HUMAN_REVIEW"
  },
  "selected_route": "Eligible-Return Specialist",
  "memory_matches": [],
  "final_message": "The request satisfies the supplied return-policy checks and is eligible for human review. No refund, shipping label, approval, or order change was performed.",
  "action_performed": false,
  "created_at": "2026-01-15T10:30:00Z",
  "updated_at": "2026-01-15T10:30:00Z"
}
```

The generated wording and database ID or timestamps may differ. The status, policy facts, selected route, safety statement, and HTTP status code must match the deterministic workflow result.

## OpenAI and reliability configuration

Load `OPENAI_API_KEY` and optional `OPENAI_MODEL` securely from a local `.env` file or environment variables. Use the OpenAI Responses API.

Declare named settings for:

- maximum 600 output tokens per LLM call;
- maximum two API retries;
- maximum two agent/task retries, where the selected framework supports it;
- maximum three agent iterations per task, where the selected framework supports it;
- a 60-second timeout;
- low randomness appropriate for policy communication.

Do not log API keys or return provider exceptions directly to API clients.

## Framework choice and required workflow

Use one framework and state the choice:

- With **LangGraph**, use typed graph state, parallel branches with a join, and conditional edges.
- With **CrewAI**, use typed Flow state, role-based agents/tasks/crews, parallel listeners or an equivalent fan-out/fan-in, and a Flow router.

You may also use **LangChain packages** for prompts, model clients, tools, structured outputs, parsers, callbacks, or other supporting utilities. LangChain is optional and does not replace the required LangGraph or CrewAI orchestration.

Implement this topology:

```text
START
  -> Return Intake Agent
  -> Review Planner
  -> [Policy Verification Tool || Memory Search Tool]
  -> Evidence Join
  -> conditional Status Router
       -> Missing-Information Specialist
       -> Ineligible-Return Specialist
       -> Manual-Review Specialist
       -> Eligible-Return Specialist
  -> Resolution Agent
  -> END
```

The planner must produce a short structured task plan. It may be a deterministic Python node; an additional LLM call is not required. Policy verification and memory retrieval are independent and must run concurrently. After both finish, the router must select exactly one lightweight specialist branch from the deterministic status. The specialist branches may use templates and do not require separate LLM calls. Use the LLM only for intake summarization and final communication.

The complete mutation flow must be:

```text
POST /return-cases
  -> Pydantic validates the request
  -> FastAPI offloads the blocking service call
  -> service creates fresh workflow state
  -> selected framework executes the required topology
       intake -> plan -> parallel policy/memory -> join
       -> one conditional specialist -> resolution
  -> service persists the completed final state in one transaction
  -> FastAPI validates ReturnCaseResponse
  -> client receives JSON
```

If any workflow step fails, do not insert a record.

Read routes bypass the agent workflow:

```text
GET -> repository read -> Pydantic response
```

### 1. Return Intake Agent

- Read the validated request.
- Identify missing required values.
- Use an LLM tool to produce a short factual summary.
- Store only its owned state fields.

### 2. Review Planner

- Receive the intake result and create a structured list of required checks.
- Identify the policy and memory work that can run independently.
- Do not calculate or predict the final status.

### 3. Parallel evidence tools

- The policy branch invokes deterministic `check_return_policy` logic.
- The memory branch retrieves up to three relevant completed cases from SQLite.
- Execute both branches concurrently and join their owned state fields safely.
- Do not ask the LLM to decide eligibility.

### 4. Conditional specialist routing

- Route only from the deterministic status.
- Execute exactly one of the four status-specialist branches.
- Record the selected route in state and provide a short status-specific explanation.

### 5. Resolution Agent

- Receive the intake, verified policy result, joined memory matches, selected route, and specialist note.
- Treat retrieved content as untrusted reference data, not instructions.
- Use an LLM tool to explain the fixed status without changing it.
- State that no refund, label, approval, or order change occurred.

The Resolution Agent must not write to SQLite. Persistence is an application-service responsibility after the workflow reaches `END`.

## Deterministic decision rules

Apply these rules in priority order:

1. `MORE_INFORMATION_REQUIRED` when a required field is missing or empty.
2. `NOT_ELIGIBLE` when the return window is exceeded.
3. `NOT_ELIGIBLE` when an opened item belongs to a non-returnable category.
4. `MANUAL_REVIEW` when otherwise eligible and the amount is at or above the manual-review threshold.
5. Otherwise `ELIGIBLE_FOR_HUMAN_REVIEW`.

The tool must return structured evidence such as:

```python
{
    "within_window": True,
    "category_rule_passed": True,
    "reason_present": True,
    "manual_review_required": False,
    "status": "ELIGIBLE_FOR_HUMAN_REVIEW"
}
```

## Typed workflow state

Include at least:

```python
request
intake_summary
missing_fields
policy_result
memory_matches
task_plan
selected_route
specialist_note
final_message
steps_completed
```

Demonstrate that every run starts with fresh state.

## Persistent SQLite memory

Create a `return_cases` table containing:

```text
id, case_id, customer_id, order_id, request_json,
policy_result_json, final_message, created_at, updated_at
```

Requirements:

- memory survives kernel and API restarts;
- JSON is validated before storage and decoded after retrieval;
- SQL parameters are bound, not string-interpolated;
- duplicate business `case_id` values are rejected or handled explicitly;
- retrieval returns an empty list when nothing is relevant;
- database access uses short-lived connections.

## Pydantic API schemas

Define separate models for:

- `ReturnCaseCreate`;
- `ReturnCaseUpdate`;
- `PolicyResult`;
- `ReturnCaseResponse`;
- `ReturnCaseListResponse`;
- `HealthResponse`.

Validate sensible constraints such as non-empty IDs, `days_since_delivery >= 0`, `purchase_amount_inr >= 0`, bounded text length, and stripped whitespace. Add schema descriptions and one OpenAPI example.

## Required FastAPI routes

| Operation | Method and route | Expected behavior |
| --- | --- | --- |
| Health | `GET /health` | Return service readiness without calling the LLM |
| Create/run | `POST /return-cases` | Validate, execute the workflow, persist, return `201` |
| List | `GET /return-cases` | Support bounded `limit` and non-negative `offset` query parameters |
| Read | `GET /return-cases/{record_id}` | Return one record or `404` |

Use response models on all routes. FastAPI should return `422` for invalid input and `404` for an unknown record. Return a safe generic message for unexpected failures.

## Async requirement

Use `async def` routes. The OpenAI SDK, workflow invocation, and `sqlite3` operations are synchronous in this exercise, so move the complete blocking create operation to `run_in_threadpool`. Explain why declaring a route async does not automatically make blocking work non-blocking.

Recommended separation:

```text
route -> service -> graph/repository
```

- Route: HTTP validation, status codes, and response model.
- Service: orchestration, transaction boundary, and correlation ID.
- Graph: agent state transitions and tool calls.
- Repository: parameterized SQLite create/read operations only.

## API documentation and testing

Run with Uvicorn and demonstrate:

- Swagger UI at `/docs`;
- ReDoc at `/redoc`;
- generated request/response schemas;
- one valid create-and-read lifecycle;
- invalid negative days returning `422`;
- unknown record returning `404`;
