# Week 1 - Hands-on Practice

These learner notebooks mirror the completed Week 1 solutions but intentionally leave the main implementation work as `TODO` blocks. Setup, mock data, rubrics, and validation are provided so learners can focus on the core concept.

## Practice sequence

| Notebook | Learner task | Provided | Learner completes |
| --- | --- | --- | --- |
| `HandsOn1.ipynb` | Chatbot-vs-agent classification | Mock scenarios and LLM setup | Prompt, LLM call, and returned answer |
| `HandsOn2.ipynb` | Enterprise agent-need analysis | Mock use cases, state, and first LangGraph node | Decision node and graph connections |
| `HandsOn3.ipynb` | Agent-type classification | Mock scenarios and first CrewAI agent/task | Classifier agent/task and sequential crew |

## Hands-On 1: Direct LLM approach

Complete `classify_scenario()` so it:

1. includes the selected mock scenario and classification rubric in the prompt;
2. requests one fixed chatbot-or-agent label;
3. calls `client.responses.create(...)`;
4. returns `response.output_text`.

No agent framework is needed because this is one input, one decision, and one output.

## Hands-On 2: Two-node LangGraph approach

The Requirements Analysis Agent is provided. Complete:

1. `agent_need_decision_agent()`;
2. both graph nodes;
3. the edges for `START → analyze_requirements → decide_agent_need → END`;
4. graph compilation.

## Hands-On 3: Two-agent CrewAI approach

The Behavior Analysis Agent and its task are provided. Complete:

1. the Agent-Type Classification Agent;
2. its classification task with `context=[analysis_task]`;
3. the crew with both agents and tasks;
4. `Process.sequential` execution.

## Recommended learner workflow

1. Add `OPENAI_API_KEY` to the Week 1 `.env` file.
2. Run the notebook until the first `NotImplementedError`.
3. Read the nearby TODO instructions and complete only that section.
4. Remove the corresponding `NotImplementedError` after implementing the code.
5. Run the remaining cells and check the validation result.
6. Test another mock scenario.
7. Compare with `Hands-on-Practice-Solution` only after attempting the exercise.

Do not copy API keys into notebooks or commit them to source control. LLM wording may vary; use the fixed first-line label and the reasoning rubric when checking an answer.
