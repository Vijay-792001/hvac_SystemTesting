# Week 2 - Hands-on Practice

These learner assignments apply the Week 2 concepts to business domains that differ from the travel-focused instructor demonstrations. Learners should transfer the demonstrated patterns instead of copying the demo implementation.

The matching solution notebooks use the same section order, names, data contracts, and validation expectations. Solutions should remain instructor-only until assignments are complete.

## Learning outcomes

By completing these assignments, learners should be able to:

- decompose a complex business request into manageable work;
- use prompt templates with variable input;
- distinguish LLM reasoning from deterministic tools;
- pass structured state through a LangGraph workflow;
- define role-based CrewAI agents and tasks;
- apply output, retry, and sampling controls appropriately;
- validate intermediate and final results;
- preserve human approval for real-world actions.

## Assignment sequence

| Notebook | Business use case | Main topic |
| --- | --- | --- |
| `HandsOn1.ipynb` | Procurement approval | LangGraph state, prompts, and tools |
| `HandsOn2.ipynb` | IT incident triage | CrewAI roles, tasks, and tools |
| `HandsOn3.ipynb` | Order readiness | Parallel LangGraph, conditional edges, and memory |

## Hands-On 1: Procurement approval

Complete the missing tools and workflow components for a procurement-review scenario. Preserve the provided state schema, prompt templates, function signatures, and output fields.

Run the workflow and use the provided checks to confirm that deterministic results and LLM-generated results are stored correctly.

## Hands-On 2: IT incident triage

Complete the missing CrewAI tools, agents, tasks, and execution flow for a mock IT incident. Preserve the supplied names, interfaces, and sequential structure.

The final recommendation must be grounded in available evidence and must not claim that a real device was repaired or changed.

## Hands-On 3: Parallel order readiness

Complete the missing LangGraph tools, nodes, parallel fan-out/join, conditional routing, and checkpoint-memory setup for an order-readiness review.

The workflow may recommend human approval or manual review, but it must not claim that an order, payment, or shipment was completed.

## Working with TODO blocks

TODO markers are intentionally concise. Learners are expected to use:

- the notebook's objective and rubric;
- provided function signatures and docstrings;
- state and template definitions;
- the Week 2 instructor demonstrations;
- official library documentation when needed.

Do not expect each TODO to contain a step-by-step solution. Determine the implementation from the surrounding code and learning objectives.

## Recommended learner workflow

1. Add `OPENAI_API_KEY` to the Week 2 `.env` file.
2. Optionally configure `OPENAI_MODEL`.
3. Run the notebook from the beginning.
4. Read the objective, rubric, schemas, and provided interfaces.
5. Complete one TODO block at a time.
6. Inspect intermediate results before running the complete workflow.
7. Run all supplied validation checks.
8. Restart the kernel and run all cells again before submission.
9. Save the notebook according to the instructor's output policy.

## Submission requirements

- Complete every TODO block.
- Preserve supplied names, parameters, return types, and state keys.
- Do not remove or weaken validation checks.
- Remove `NotImplementedError` after implementing the corresponding function.
- Do not hard-code API keys or other credentials.
- Do not include unrelated errors or stale output.
- Do not copy code from the solution folder.

## Model-control guidance

The notebooks demonstrate output-token limits, retries, temperature, and `top_p`. CrewAI assignments also use iteration and agent-retry limits.

OpenAI does not support a `top_k` request parameter. Do not add unsupported parameters to an API call. Some reasoning models require default sampling values; the provided configuration handles that compatibility rule.

## Assessment focus

Assignments are evaluated on:

- correct architecture and execution order;
- appropriate separation of reasoning and tools;
- valid state and context handling;
- correct data types and calculations;
- successful validation;
- clear, safe final output;
- code readability and adherence to the provided interfaces.

LLM wording can vary. Required structure, state, tool results, calculations, and safety constraints must remain correct.
