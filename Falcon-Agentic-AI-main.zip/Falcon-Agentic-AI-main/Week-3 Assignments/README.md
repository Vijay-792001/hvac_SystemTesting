# Week 3 — Hands-on Practice

These notebooks are intentionally incomplete learner scaffolds. Complete the agent, workflow, tool, and memory TODOs, then compare your work with the corresponding solution.

## Practice sequence

| Practice notebook | Pattern | Main learner tasks | Matching solution |
| --- | --- | --- | --- |
| [HandsOn1.ipynb](HandsOn1.ipynb) | LangGraph planner and parallel executors | E-commerce order investigation, evidence fan-out/fan-in, SQLite persistence | [Solution](../Hands-on-Practice-Solution/HandsOn1.ipynb) |
| [HandsOn2.ipynb](HandsOn2.ipynb) | LangGraph conditional router | Employee payroll, leave, benefits, and policy requests | [Solution](../Hands-on-Practice-Solution/HandsOn2.ipynb) |
| [HandsOn3.ipynb](HandsOn3.ipynb) | CrewAI Router Flow | Retail billing, delivery, returns, and fraud requests | [Solution](../Hands-on-Practice-Solution/HandsOn3.ipynb) |

## Learner workflow

1. Create `Week3/.env` and set `OPENAI_API_KEY`. You may also set `OPENAI_MODEL`.
2. Open a notebook with its working directory set to `Week3/Hands-on-Practice`.
3. Run the setup cells and complete every TODO.
4. Build and run the graph or CrewAI Flow.
5. Inspect the selected route, tool evidence, and final response.
6. Persist the completed result only after the workflow succeeds, then verify retrieval with relevant search terms.
7. Test the additional cases requested in the notebook.
8. Compare your implementation with the matching solution.

Runtime databases are created under `Week3/Hands-on-Practice/databases` and are excluded from Git. All tools use mock data; they do not change real orders, employee records, accounts, or devices.
